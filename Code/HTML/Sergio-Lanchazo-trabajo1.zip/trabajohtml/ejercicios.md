# Ejercicios

1. Cread un `blog.html` sobre un tema que queramos desarrollar con las siguientes características:
    - Título principal
    - Lista de Posts (2-3)
    - Al hacer click en un post debe abrirse la página del post
    - Para cada post, se debe colocar:
        - título
        - imagen
        - descripción
2. Haced las páginas de cada post, por ejemplo, `post-1.html`, etc. Cada una de esta página debe tener estas características:
    - Título principal
    - Algunas secciones (2 o 3)
    - Algunos párrafos
    - Algún enlace
    - Alguna imagen o GIF

3. Considerad como colocar una navegación entre los archivos:
    - Post siguiente
    - Post anterior
    - Inicio > `blog.html` 


